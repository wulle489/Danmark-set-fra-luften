import os
from urllib.parse import quote

from qgis.PyQt.QtCore import QSettings
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction, QFileDialog, QInputDialog, QMessageBox
from qgis.core import (
    QgsCoordinateReferenceSystem,
    QgsCoordinateTransform,
    QgsFeatureRequest,
    QgsProject,
    QgsVectorLayer,
)


class KBLuftfotoRefreshPlugin:
    MENU_NAME = "KB Luftfoto Refresh"
    LAYER_NAME_PREFIX = "KB luftfoto"
    SETTINGS_KEY_STYLE = "KBLuftfotoRefresh/stylePath"
    SETTINGS_KEY_FILTER = "KBLuftfotoRefresh/filterKey"
    BASE_URL = "https://www.kb.dk/cop/syndication/images/luftfo/2011/maj/luftfoto/subject203"
    FILTERS = {
        "all": {
            "label": "Alle",
            "layer_suffix": "(current view)",
            "expression": None,
        },
        "lodfoto": {
            "label": "Lodfoto",
            "layer_suffix": "- Lodfoto (current view)",
            "expression": '"subjectGenre" = \'Lodfoto\'',
        },
        "skraafoto": {
            "label": "Skråfoto",
            "layer_suffix": "- Skråfoto (current view)",
            "expression": '"subjectGenre" = \'Skråfoto\'',
        },
        "andre": {
            "label": "Andre",
            "layer_suffix": "- Andre (current view)",
            "expression": '"subjectGenre" IS NULL OR ("subjectGenre" <> \'Lodfoto\' AND "subjectGenre" <> \'Skråfoto\')',
        },
    }
    FILTER_ORDER = ["all", "lodfoto", "skraafoto", "andre"]

    def __init__(self, iface):
        self.iface = iface
        self.refresh_action = None
        self.filter_action = None
        self.style_action = None
        self.direct_filter_actions = []
        self.icon = None

    def initGui(self):
        icon_path = os.path.join(os.path.dirname(__file__), "icon.png")
        self.icon = QIcon(icon_path) if os.path.exists(icon_path) else QIcon.fromTheme("view-refresh")

        self.refresh_action = QAction(self.icon, "Refresh KB Luftfoto", self.iface.mainWindow())
        self.refresh_action.setObjectName("KBLuftfotoRefreshAction")
        self.refresh_action.triggered.connect(self.refresh_layer)

        self.filter_action = QAction("Set billedtype...", self.iface.mainWindow())
        self.filter_action.setObjectName("KBLuftfotoSetFilterAction")
        self.filter_action.triggered.connect(self.select_filter)

        self.style_action = QAction("Set KB style (.qml)...", self.iface.mainWindow())
        self.style_action.setObjectName("KBLuftfotoSetStyleAction")
        self.style_action.triggered.connect(self.select_style)

        self.iface.addToolBarIcon(self.refresh_action)
        self.iface.addPluginToMenu(self.MENU_NAME, self.refresh_action)
        self.iface.addPluginToMenu(self.MENU_NAME, self.filter_action)

        for filter_key in self.FILTER_ORDER:
            label = self.FILTERS[filter_key]["label"]
            action = QAction(f"Refresh {label}", self.iface.mainWindow())
            action.setObjectName(f"KBLuftfotoRefresh_{filter_key}")
            action.triggered.connect(lambda checked=False, key=filter_key: self.refresh_layer(key))
            self.direct_filter_actions.append(action)
            self.iface.addPluginToMenu(self.MENU_NAME, action)

        self.iface.addPluginToMenu(self.MENU_NAME, self.style_action)
        self._update_refresh_action_text()

    def unload(self):
        if self.refresh_action is not None:
            self.iface.removeToolBarIcon(self.refresh_action)
            self.iface.removePluginMenu(self.MENU_NAME, self.refresh_action)
        if self.filter_action is not None:
            self.iface.removePluginMenu(self.MENU_NAME, self.filter_action)
        for action in self.direct_filter_actions:
            self.iface.removePluginMenu(self.MENU_NAME, action)
        if self.style_action is not None:
            self.iface.removePluginMenu(self.MENU_NAME, self.style_action)

    def select_style(self):
        current = QSettings().value(self.SETTINGS_KEY_STYLE, "", type=str)
        start_dir = os.path.dirname(current) if current and os.path.exists(current) else ""
        style_path, _ = QFileDialog.getOpenFileName(
            self.iface.mainWindow(),
            "Select KB style file",
            start_dir,
            "QGIS Layer Style (*.qml)"
        )
        if style_path:
            QSettings().setValue(self.SETTINGS_KEY_STYLE, style_path)
            self.iface.messageBar().pushSuccess(
                "KB Luftfoto Refresh",
                f"Style file saved: {os.path.basename(style_path)}"
            )

    def _current_filter_key(self):
        filter_key = QSettings().value(self.SETTINGS_KEY_FILTER, "all", type=str)
        if filter_key not in self.FILTERS:
            filter_key = "all"
        return filter_key

    def _set_current_filter_key(self, filter_key):
        if filter_key not in self.FILTERS:
            filter_key = "all"
        QSettings().setValue(self.SETTINGS_KEY_FILTER, filter_key)
        self._update_refresh_action_text()

    def _update_refresh_action_text(self):
        if self.refresh_action is None:
            return
        current_label = self.FILTERS[self._current_filter_key()]["label"]
        self.refresh_action.setText(f"Refresh KB Luftfoto ({current_label})")
        self.refresh_action.setToolTip(f"Refresh KB Luftfoto using filter: {current_label}")
        self.refresh_action.setStatusTip(f"Refresh KB Luftfoto using filter: {current_label}")

    def select_filter(self):
        labels = [self.FILTERS[key]["label"] for key in self.FILTER_ORDER]
        current_key = self._current_filter_key()
        current_label = self.FILTERS[current_key]["label"]
        selection, ok = QInputDialog.getItem(
            self.iface.mainWindow(),
            "KB Luftfoto billedtype",
            "Vælg billedtype:",
            labels,
            labels.index(current_label),
            False,
        )
        if ok and selection:
            for key in self.FILTER_ORDER:
                if self.FILTERS[key]["label"] == selection:
                    self._set_current_filter_key(key)
                    self.iface.messageBar().pushSuccess(
                        "KB Luftfoto Refresh",
                        f"Billedtype sat til: {selection}"
                    )
                    break

    def _layer_name_for_filter(self, filter_key):
        suffix = self.FILTERS[filter_key]["layer_suffix"]
        return f"{self.LAYER_NAME_PREFIX} {suffix}"

    def _remove_existing_layers(self, project):
        for layer in list(project.mapLayers().values()):
            if layer.name().startswith(self.LAYER_NAME_PREFIX):
                project.removeMapLayer(layer.id())

    def _build_base_layer(self, layer_name):
        project = QgsProject.instance()
        canvas = self.iface.mapCanvas()
        extent = canvas.extent()
        canvas_crs = canvas.mapSettings().destinationCrs()
        wgs84 = QgsCoordinateReferenceSystem("EPSG:4326")

        if canvas_crs != wgs84:
            transform = QgsCoordinateTransform(canvas_crs, wgs84, project)
            extent_wgs84 = transform.transformBoundingBox(extent)
        else:
            extent_wgs84 = extent

        # KB examples indicate bbo order: xmax,ymax,xmin,ymin
        bbo = (
            f"{extent_wgs84.xMaximum()},"
            f"{extent_wgs84.yMaximum()},"
            f"{extent_wgs84.xMinimum()},"
            f"{extent_wgs84.yMinimum()}"
        )

        url = (
            f"{self.BASE_URL}?bbo={quote(bbo, safe=',.-')}"
            "&itemsPerPage=500"
            "&page=1"
            "&format=kml"
        )

        return QgsVectorLayer(url, layer_name, "ogr"), url

    def _filter_layer(self, base_layer, filter_key, layer_name):
        expression = self.FILTERS[filter_key]["expression"]
        if not expression:
            return base_layer

        request = QgsFeatureRequest().setFilterExpression(expression)
        filtered_layer = base_layer.materialize(request)
        filtered_layer.setName(layer_name)
        return filtered_layer

    def refresh_layer(self, filter_key=None):
        try:
            if filter_key is None:
                filter_key = self._current_filter_key()
            else:
                self._set_current_filter_key(filter_key)

            if filter_key not in self.FILTERS:
                filter_key = "all"

            layer_name = self._layer_name_for_filter(filter_key)
            base_layer, url = self._build_base_layer(layer_name)
            if not base_layer.isValid():
                self.iface.messageBar().pushWarning(
                    "KB Luftfoto Refresh",
                    "Layer failed to load from the current map extent."
                )
                return

            result_layer = self._filter_layer(base_layer, filter_key, layer_name)
            if not result_layer or not result_layer.isValid():
                self.iface.messageBar().pushWarning(
                    "KB Luftfoto Refresh",
                    "Layer loaded, but filtering failed."
                )
                return

            style_path = QSettings().value(self.SETTINGS_KEY_STYLE, "", type=str)
            if style_path:
                if os.path.exists(style_path):
                    result = result_layer.loadNamedStyle(style_path)
                    result_layer.triggerRepaint()
                    if isinstance(result, tuple) and result and not result[0]:
                        self.iface.messageBar().pushWarning(
                            "KB Luftfoto Refresh",
                            "Layer refreshed, but the QML style could not be fully applied."
                        )
                else:
                    self.iface.messageBar().pushWarning(
                        "KB Luftfoto Refresh",
                        "Saved QML style file was not found. Use 'Set KB style (.qml)...' to update it."
                    )
            else:
                reply = QMessageBox.question(
                    self.iface.mainWindow(),
                    "KB Luftfoto Refresh",
                    "No QML style is configured yet. Refresh without style?",
                    QMessageBox.Yes | QMessageBox.No,
                    QMessageBox.Yes,
                )
                if reply == QMessageBox.No:
                    return

            project = QgsProject.instance()
            self._remove_existing_layers(project)
            project.addMapLayer(result_layer)
            self.iface.messageBar().pushSuccess(
                "KB Luftfoto Refresh",
                f"Layer refreshed from current map extent ({self.FILTERS[filter_key]['label']})."
            )
            self._update_refresh_action_text()
        except Exception as exc:
            self.iface.messageBar().pushCritical(
                "KB Luftfoto Refresh",
                f"Plugin error: {exc}"
            )
            try:
                print(url)
            except Exception:
                pass
