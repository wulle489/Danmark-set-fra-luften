# KB Luftfoto Refresh

A minimal QGIS Python plugin that adds:

- a **toolbar button**: **Refresh KB Luftfoto**
- a **Plugins menu entry**: **Refresh KB Luftfoto**
- a **Plugins menu entry**: **Set KB style (.qml)…**

The plugin reads the **current QGIS map extent**, transforms it to **EPSG:4326**, builds the KB syndication URL with `bbo=xmax,ymax,xmin,ymin`, loads the KML layer, and reapplies a saved `.qml` style if configured.

## Install

1. In QGIS, open **Plugins -> Manage and Install Plugins...**
2. Click **Install from ZIP**
3. Choose the ZIP file for this plugin
4. Enable the plugin if needed

## First use

1. Open **Plugins -> KB Luftfoto Refresh -> Set KB style (.qml)...**
2. Choose your saved layer style file
3. Click the toolbar button or **Plugins -> KB Luftfoto Refresh -> Refresh KB Luftfoto**

## Notes

- The plugin refreshes a layer named **KB luftfoto (current view)**.
- If no style is set, the plugin will still refresh the layer.
- The style path is stored in QGIS settings under the current profile.
